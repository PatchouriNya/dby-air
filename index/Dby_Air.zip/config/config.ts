const API_URL = 'http://192.168.0.176/api/dby'
export {
    API_URL
}
