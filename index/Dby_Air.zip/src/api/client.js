import request from './request'

const token = localStorage.getItem("token")
export const clientList = () => {
    return request({
        url: '/client/' + token
    })
}