import request from './request'

export const updateAir = (id, data) => {
    return request({
        url: '/air/' + id + '?_method=PUT',
        method: 'PUT',
        data: data
    })
}