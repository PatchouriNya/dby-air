<template>
  <el-breadcrumb separator="/">
    <el-breadcrumb-item style="font-size: 25px">
      东佰源空调集控系统
    </el-breadcrumb-item>
  </el-breadcrumb>
</template>

<script setup>
import {useRoute} from 'vue-router'

const route = useRoute()
// console.log(route.matched)
</script>

<style lang="scss" scoped>
.no-redirect {
  color: #97a8be;
  cursor: text;
}

.redirect {
  color: #666;
  font-weight: 600;
  cursor: pointer;

  &:hover {
    color: $menuBg;
  }
}
</style>
