import {createRouter, createWebHistory} from 'vue-router'
import index from '@/views/index.vue'
import login from '@/views/login/login.vue'
import login2 from '@/views/login/index.vue'
import register from '@/views/register/register.vue'
import layout from '@/layout/index.vue'

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            name: '/',
            component: layout,
            children: [
                {
                    path: '/main/panel/workbench',
                    name: 'workbench',
                    component: () => import('@/views/panel/workbench/index.vue')
                },
                {
                    path: '/main/list/dtulist',
                    name: 'dtulist',
                    component: () => import('@/views/list/dtulist/index.vue')
                },
                {
                    path: '/main/energy/intelligentcontrol/splitcontrol',
                    name: 'splitcontrol',
                    component: () => import('@/views/energy/intelligentcontrol/splitcontrol/index.vue')
                }
            ]
        },
        {
            path: '/index',
            name: '系统主页1',
            component: index
        },
        {
            path: '/login',
            name: '登陆界面',
            component: login
        },
        {
            path: '/register',
            name: '用户注册',
            component: register
        },
        {
            path: '/login2',
            name: 'login2',
            component: login2
        }
    ]
})

export default router
