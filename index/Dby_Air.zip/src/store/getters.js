export default {
  token: (state) => state.app.token,
  siderType: (state) => state.app.siderType,
  lang: (state) => state.app.lang
}
