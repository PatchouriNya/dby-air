<template>
  <div class="homePage">
    <el-card class="userInfoCard" v-if="userInfo">
      <div class="userInfo">
        <h2 class="welcomeMsg">欢迎，{{ userInfo.clientname }}！</h2>
        <ClientItem :client="userInfo" @select-client="updateSelectedClient"/>
        <p v-if="selectedClient"><strong>公司名称:</strong> {{ selectedClient.clientname }}</p>
        <p v-if="selectedClient"><strong>内机数量:</strong> {{ selectedClient.with_overview.air_quantity }}</p>
        <p v-if="selectedClient"><strong>开机数量:</strong> {{ selectedClient.with_overview.air_boot_quantity }}</p>
        <p v-if="selectedClient"><strong>开机温度:</strong> {{ selectedClient.with_overview.air_startup_temperature }}
        </p>
        <p v-if="selectedClient"><strong>空调功率:</strong> {{ selectedClient.with_overview.air_conditioning_power }}
        </p>
      </div>
      <el-button type="primary" @click="logout">退出登录</el-button>
    </el-card>
    <el-alert
        v-else
        title="无法获取用户信息"
        type="error"
        show-icon
        description="请检查登录状态或稍后重试"
    />
  </div>
</template>

<script setup>
import {ref, onMounted, getCurrentInstance, defineEmits} from 'vue';
import {ElCard, ElButton, ElAlert, ElMessage} from 'element-plus';
import axios from 'axios';
import {useRouter} from 'vue-router';
import ClientItem from '@/components/ClientItem.vue'; // 引入递归组件

const router = useRouter();
const userInfo = ref(null);
const selectedClient = ref(null);

const {emit} = defineEmits(['select-client']);

onMounted(async () => {
  try {
    const token = localStorage.getItem("token");
    if (token) {
      const response = await axios.get(getCurrentInstance().proxy.$API_URL + '/client' + '/' + token, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      userInfo.value = response.data.data;
      selectedClient.value = response.data.data;
      // console.log(userInfo.value);
    }
  } catch (error) {
    console.error('无法获取用户信息', error);
  }
});

function logout() {
  localStorage.removeItem("token")
  router.push({path: '/login'})
  ElMessage.success('登出成功')
}

function updateSelectedClient(client) {
  selectedClient.value = client;
}
</script>

<style scoped>
.homePage {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.userInfoCard {
  margin-bottom: 20px;
}

.userInfo {
  padding: 20px;
}

.welcomeMsg {
  margin-top: 0;
  margin-bottom: 10px;
  font-size: 24px;
}
</style>
